import React from 'react';
import './contact.css'; // Ensure this CSS file exists and is styled appropriately

const contacts = [
  { id: 1, name: "Johnny", phone: "0987654321", email: "abc135@gmail.com", avatar: "https://t3.ftcdn.net/jpg/02/17/44/98/360_F_217449874_RiBnrBbn3MI02ub8dUk6be2cKQzLSwkk.jpg" },
  { id: 2, name: "Gyro", phone: "023456781", email: "def754@gmail.com", avatar: "https://st3.depositphotos.com/1135494/16766/i/450/depositphotos_167668598-stock-photo-happy-middle-aged-man-outside.jpg" },
  { id: 3, name: "Đồng", phone: "0192837465", email: "unknown875@gmail.com", avatar: "https://cdn.britannica.com/05/88205-050-9EEA563C/Bigmouth-buffalo-fish.jpg" },
  { id: 4, name: "Cao", phone: "0129384756", email: "mystery234@gmail.com", avatar: "https://media.istockphoto.com/id/1387958208/vector/triceraptops-dinosaur-isolated-comic-book-style-vector-illustration.jpg?s=612x612&w=0&k=20&c=QjEc88OYyq_YwMKI8-dOsAZtInwyRAjotbBlyp2FgoA=" },
];

const ContactList = () => {
  const backgroundStyle = {
    background: 'url("https://gtwallpaper.org/sites/default/files/wallpaper/165381/night-sky-1920x1080-wallpapers-165381-101557-3635423.png") no-repeat center center fixed',
    backgroundSize: 'cover',
    minHeight: '100vh',
    padding: '20px',
  };

  return (
    <div style={backgroundStyle} className="contact-list-container">
      <a href="/tourguide" className="home-button">Back to page</a>
      <div className="contact-list">
        <h2>Danh sách liên lạc Admin</h2>
        <table className="contact-table">
          <thead>
            <tr>
              <th>Đại diện</th>
              <th>Tên</th>
              <th>Số điện thoại</th>
              <th>Email</th>
            </tr>
          </thead>
          <tbody>
            {contacts.map(contact => (
              <tr key={contact.id}>
                <td><img src={contact.avatar} alt={contact.name} className="contact-avatar" /></td>
                <td>{contact.name}</td>
                <td>{contact.phone}</td>
                <td>{contact.email}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ContactList;
