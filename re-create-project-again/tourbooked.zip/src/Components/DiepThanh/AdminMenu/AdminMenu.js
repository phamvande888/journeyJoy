// import React from 'react';
// import { useTranslation } from 'react-i18next';

// const AdminMenu = () => {
//   const { t } = useTranslation();

//   return (
//     <div className="admin-menu">
//       <h2>{t('adminMenu')}</h2>
//       {/* Add other admin menu items here as needed */}
//     </div>
//   );
// };

// export default AdminMenu;
