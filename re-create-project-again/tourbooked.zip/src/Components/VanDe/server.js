//sever Lam
export const URL_SERVER = "https://engaging-giraffe-fast.ngrok-free.app"; //lam
// export const URL_SERVER = "https://quiet-bedbug-social.ngrok-free.app"; //phat
// export const URL_SERVER = "https://8748-113-22-221-110.ngrok-free.app"; //khoa
