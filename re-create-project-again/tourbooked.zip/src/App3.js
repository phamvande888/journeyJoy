import React from "react";
import { BrowserRouter } from "react-router-dom";
import Sidebar from "./Components/Quang/TourGuideSite/SideBar/Sidebar";
export default function App3() {
  return (
    <BrowserRouter>
      <Sidebar />;
    </BrowserRouter>
  );
}
